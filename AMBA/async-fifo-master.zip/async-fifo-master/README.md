# async-fifo
Asynchronous FIFO for transferring data between two asynchronous clock domains

![alt tag](https://raw.githubusercontent.com/akhan3/async-fifo/master/top.png)
